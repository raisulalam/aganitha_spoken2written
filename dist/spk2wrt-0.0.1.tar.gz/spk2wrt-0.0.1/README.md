# Example Package

This is a simple example packages for below

Create a reusable library that can convert a paragraph of spoken english to written english. For example, "two dollars" should be converted to $2. Abbreviations spoken as "C M" or "Triple A" should be written as "CM" and "AAA" respectively. Push your code to a public github/gitlab/bitbucket repo and submit the link here.